<?php
/**
 * Copyright (C) Baluart.COM - All Rights Reserved
 *
 * @since 1.12.2
 * @author Baluart E.I.R.L.
 * @copyright Copyright (c) 2015 - 2021 Baluart E.I.R.L.
 * @license http://codecanyon.net/licenses/faq Envato marketplace licenses
 * @link https://easyforms.dev/ Easy Forms
 */

namespace app\components\liquid;

use app\components\liquid\Liquid\Template as BaseTemplate;

/**
 * Class Template
 * @package app\components\liquid
 */
class Template extends BaseTemplate
{
    //
}